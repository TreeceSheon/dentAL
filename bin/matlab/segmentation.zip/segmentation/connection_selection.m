function outline = connection_selection(map)
    
    while true
        
        lap_operator = [0 1 0; 1 -4 1;0 1 0];
        areas = bwlabel(map, 4);
        lap_areas = filter2(lap_operator, areas);
        
        if sum(lap_areas(lap_areas == 5)) ~= 0
            
            se = strel('square', 10);

            map = imfill(map, 'hole');

            map = imdilate(map, se);
        
        else
            break
        
        end
    end
        

    ii = 1;
    count = 0;
    idx = 0;

    while(true)
        
        new_count = lap_areas == ii;
        new_count = sum(new_count(:));

        if new_count == 0

            break;
        
        end

        count = max(count, new_count);

        if count == new_count
            
            idx = ii;
        
        end

       ii = ii + 1;
    
    end
    
    outline = zeros(size(lap_areas));

    outline(lap_areas == idx) = 1;

end


    