clc;
clear;

oral_model = niftiread('G:\dentAL\data\down\single\0002\0002.nii');

thers_map = oral_model > 500 & oral_model < 2500;

mask = zeros(size(oral_model));
mask(thers_map) = 1;

oral_model(mask ~= 1) = 0;

niftiwrite(oral_model, 'tmodel')


slice_no = 209;

slice = squeeze(oral_model(slice_no, :, :));

lap_operator = [0 1 0; 1 -4 1;0 1 0];


%% dilation

se = strel('square', 10);

slice = imfill(slice, 'hole');

dilated_slice = imdilate(slice, se);

% imshow(dilated_slice)

%% 2D cluster segmentation

[cluster1, cluster2] = oral_seg_cluster(dilated_slice);

%% 2D OTSU segmentation

[OTSU_background, OTSU_gum] = oral_seg_OTSU(dilated_slice);

%% outline selection

OTSU_outline_gum = connection_selection(OTSU_gum);
cluster_outline1 = connection_selection(cluster1);
cluster_outline2 = connection_selection(cluster2);


niftiwrite(OTSU_outline_gum, 'OTSU_gum');
niftiwrite(cluster_outline1, 'cluster1');
niftiwrite(cluster_outline2, 'cluster2')






