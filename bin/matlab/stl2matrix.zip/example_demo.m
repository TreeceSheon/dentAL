clear
clc

[stlcoords, coordNORMALS] = READ_stl('lower.stl');

cx1 = squeeze( stlcoords(:,1,:) );
cy1 = squeeze( stlcoords(:,2,:) );
cz1 = squeeze( stlcoords(:,3,:) );

[stlcoords2, coordNORMALS2] = READ_stl('upper.stl');
% [hpat] = patch(xco,yco,zco,'b');
% axis equal

cx2 = squeeze( stlcoords2(:,1,:) );
cy2 = squeeze( stlcoords2(:,2,:) );
cz2 = squeeze( stlcoords2(:,3,:) );

cx = [cx1; cx2]; 
cy = [cy1; cy2]; 
cz = [cz1; cz2]; 

gridX = min(cx) : (max(cx) - min(cx))/511 : max(cx);
gridY = min(cy) : (max(cy) - min(cy))/511 : max(cy);
gridZ = min(cz) : (max(cz) - min(cz))/511 : max(cz);

%Voxelise the STL:
[OUTPUTgrid] = VOXELISE(gridX,gridY,gridZ,'lower.stl','xyz');

niftiwrite(single(OUTPUTgrid), 'lower_converted.nii')


[OUTPUTgrid2] = VOXELISE(gridX,gridY,gridZ,'upper.stl','xyz');

niftiwrite(single(OUTPUTgrid2), 'upper_converted.nii')

niftiwrite(single(OUTPUTgrid2 + OUTPUTgrid), 'combined_converted.nii')

% 
% gridX = min(cx1) : (max(cx1) - min(cx1))/511 : max(cx1);
% gridY = min(cy1) : (max(cy1) - min(cy1))/511 : max(cy1);
% gridZ = min(cz1) : (max(cz1) - min(cz1))/511 : max(cz1);


% OUTPUTgrid = imresize3(OUTPUTgrid, [1024, 1024, 1024]); 
% OUTPUTgrid2 = imresize3(OUTPUTgrid2, [1024, 1024, 1024]); 
% 
% gridX = min(cx) : (max(cx) - min(cx))/1023 : max(cx);
% gridY = min(cy) : (max(cy) - min(cy))/1023 : max(cy);
% gridZ = min(cz) : (max(cz) - min(cz))/1023 : max(cz);

tic
CONVERT_voxels_to_stl('lower_convert_back.stl',OUTPUTgrid,gridX,gridY,gridZ,'binary');
toc 

% gridX = min(cx2) : (max(cx2) - min(cx2))/511 : max(cx2);
% gridY = min(cy2) : (max(cy2) - min(cy2))/511 : max(cy2);
% gridZ = min(cz2) : (max(cz2) - min(cz2))/511 : max(cz2);

tic
CONVERT_voxels_to_stl('upper_convert_back.stl',OUTPUTgrid2,gridX,gridY,gridZ,'binary');
toc 




